Thanks for choosing Voyage Theme.
--------------------------------------------------------------------------------
 Documentation :
--------------------------------------------------------------------------------
For documentations and user guides, 
visit http://www.voyagebc.com/voyage-theme-documentation
--------------------------------------------------------------------------------
For support, 
visit http://www.voyagebc.com/support
--------------------------------------------------------------------------------
 Limitations:
--------------------------------------------------------------------------------
* For fixed top-menu option, please ensure that top level menu items
  can be fit into one line.
--------------------------------------------------------------------------------
 Licenses:
--------------------------------------------------------------------------------
The Voyage Theme licensed under GPL3. See license.txt for further details.

The resources used in Voyage Theme are all GPL-compatible:

Macchiato – Social & spirit20 icons are licensed under GPL
http://19eighty7.com/icons

ColorBox JQuery Plugin and its resourcs (images/colorbox) are licensed under MIT
http://www.jacklmoore.com/colorbox

Twitter Boostrap is licensed under Apache License v2.0
http://twitter.github.com/bootstrap/

Font Awesome is licensed under SIL Open Font License for font and MIT for CSS.
http://fortawesome.github.com/Font-Awesome/

Infinite Scroll is licensed under GPL 3.0
http://www.infinite-scroll.com/

JQuery Mobile Menu is release under Public Domain
https://github.com/mattkersley/Responsive-Menu

Skitter Slider is dual licensed under the MIT or GPL Version 2 
http://www.skitter-slider.net/

Other icons and images are created by VoyageTheme and licensed under GPL.
--------------------------------------------------------------------------------
